import os, sys

__cwd__ = os.getcwd().replace(";","")
sys.path.append(os.path.join(__cwd__, 'libs'))
sys.path.append(os.path.join(__cwd__, 'external'))

import mc
    
mc.ActivateWindow(15000)
mc.ActivateWindow(15110)
mc.ActivateWindow(15100)

import navi

if ( __name__ == "__main__" ):
    if len(mc.GetWindow(15000).GetList(60).GetItems()) < 1:
        app = navi.Navi_APP()
    else:
        app.api.download.active = False
        app.gui.HideDialog('wait')
    app.gui.HideDialog('splash')

