Welcome to Navi-X for Boxee v1.3

Changelog:
-New processor features to access more content (thanks to Turner3D);
-Favorite Support added;
-Minor bug fixes;

This version has been tested on:
-Boxee 0.9.23.15885 (vWindows XP)
-Boxee Box

##########################

