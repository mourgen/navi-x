Welcome to Navi-X for Boxee v1.4

Changelog:
-Improved HTML support. Mouse and keyboard controls are now support.
-Moved the Navi-X media portal to the Navi-Xtreme website. Visit Navi-Xtreme at http://navix.turner3d.net/.

This version has been tested on:
-Boxee 0.9.23.15885 (vWindows XP)
-Boxee Box

##########################

