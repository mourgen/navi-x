Welcome to Navi-X for Boxee v1.1

Changelog:
-Fixed Youtube secion.
-Added left pop-up menu, press the left cursor key to show this menu. Work in progress.
-Added Navi-Xtreme login option.
-Added Boxee app installer to install Boxee apps from within Navi-X.
-GUI update.

This version has been tested on:
-Boxee 0.9.23.15885 (vWindows XP)

Don't forget to visit the Navi-xtreme website (http://navix.turner3d.net)

##########################

Rodejo (rodejo16@gmail.com)