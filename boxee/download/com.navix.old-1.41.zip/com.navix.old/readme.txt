Welcome to Navi-X for Boxee v1.5

Changelog:
##########################
1.41
-Processor engine updates
  "countdown" NIPL method added
  multiple conditions per if/elseif statement
  "error" method accepts a variable as an argument
  CURLLoader.urlopen and CPlayer.play_URL return an object instead of a single integer as their result. This enables the following (so far):
    processors can produce custom error messages
    processors can redirect to a playlist from a type=video/audio

##########################
1.4
-Improved HTML support. Mouse and keyboard controls are now support.
-Moved the Navi-X media portal to the Navi-Xtreme website. Visit Navi-Xtreme at http://navix.turner3d.net/.

This version has been tested on:
-Boxee 0.9.23.15885 (vWindows XP)
-Boxee Box

##########################

