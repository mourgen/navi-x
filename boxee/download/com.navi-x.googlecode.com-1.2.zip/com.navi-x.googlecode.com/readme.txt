Welcome to Navi-X for Boxee v1.2 Development

Changelog:
-

This version has been tested on:
-Boxee 0.9.23.15885 (vWindows XP)

Don't forget to visit the Navi-xtreme website (http://navix.turner3d.net)

##########################

Rodejo (rodejo16@gmail.com)